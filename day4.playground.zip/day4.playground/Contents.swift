//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



////////  CLOSURES   /////////


var months = [4,3,1,6,5,2]
print(months.sorted())

func reverse(_ s1: Int,_ s2: Int) -> Bool{
    return s1 > s2
}

var reversedmonths = months.sorted (by: reverse)
print("reversed months",reversedmonths)

func incr(_ s1: Int,_ s2: Int) -> Bool
{
    return s1 < s2
}

var incrmonths = months.sorted(by: incr)
print("inc months", incrmonths)

//closure expression syntax
/*
 { (parameters) -> return type in statements
 }
 */


var reverseclosure = months.sorted(by: {
    (s1: Int, s2: Int) -> Bool in
    return s1 > s2
})

print("reverse closure:",reverseclosure)
// inferring paratmer types from context

var infertypes = months.sorted(by:
{
    (s1, s2) in return s1 < s2

        // (s1, s2) in s1 < s2 implicit return

})
print("infertypes",infertypes)



            // shorthand argument names
print("shorthand" , months.sorted(by:  {$0 < $1}))




            //operated methods
print("operator methods" ,months.sorted(by : <))

var three = [1,3,4,5,6,8,9,12,15]
print("three: ",three)
var modthree = three.filter({ $0 % 3 == 0})
print("mod three:",modthree)


var evenNum = three.filter({$0 % 2 == 0})
print("even numbers area:",evenNum)




            //nested funcns closure

func makeincr(forIncrement amount: Int) -> () -> Int
{
    var runningTotal = 0
    
    func incrementer() -> Int
    {
        runningTotal += amount
        return runningTotal
    }
return incrementer
}

let incrementbyten = makeincr(forIncrement: 10)

print(" first call:",incrementbyten())    // 10
print("second call:",incrementbyten())    // 20
print("third call:",incrementbyten())     // 30


let incrementbyseven = makeincr(forIncrement: 7)
/* different inst will start from 0 again*/

print(" first call:",incrementbyseven())        // 7



print("fourth call:",incrementbyten())     // 40


print(" 2nd call:",incrementbyseven())




// closures are reference type

let incrementbysevenagain = incrementbyseven
print("inc by seven:",incrementbysevenagain)

// auto closures

 var errorlist = [404,414,402,431,455,440]
print("total error:",errorlist.count)


let debugger = {errorlist.remove(at: 0)}
print("now solving \(debugger())!")
print("total erros",errorlist.count)
print(" total erros:",errorlist)


/*
 same behaviour of delayed evaluation can be achieved when you pass a closure as an argument to a function
 
 try it from the official text swift document
 
 
 
 */


func solve(error debugger: @autoclosure () -> Int)
{
    print("now solving \(debugger())!")
    
    solve (error: errorlist.remove(at: 0))
    print("error list: ",errorlist)

}

// TASK FOR THE DAY: escaping and trailing closures

//////  CLASSES & STRUCTURES   ////////




struct project
{
    var title = " "
    var hours = 0
    
    func display()
    {
        print("project title:",title)
        print("no. of hours",hours)
    }
}

var lmsproject = project(title: "moodle",hours : 200)
print(lmsproject)

lmsproject.display()

lmsproject.hours = 300
lmsproject.display()





/// CLASS DECLARATION

class manager{
    var name: String = " "
    var productowner : Bool = true
    var currentprojects = project()

}


/// creating an instance of class

let mgrcanada = manager()
mgrcanada.name = "AD"
mgrcanada.productowner = true
mgrcanada.currentprojects = project(title: "sales reporting",hours:  20)

print("mgrcanada name :",mgrcanada.name)
print("mgrcanada productowner", mgrcanada.productowner)
print("magrcanada current projects",mgrcanada.currentprojects)


////
struct address{
    var street = "265 yorkland blvd"
    var city = "north york"
    var postalcode = "m1h1y1"
}

 var lambton = address()
print("lambton",lambton)

var cestar = lambton
cestar.street = "271 yorkland blvd"
cestar.postalcode = "m1h3y3"
print("cestar:",cestar)
print("lambton :",lambton)



/////
class inst{
    var street = "265 yorkland blvd"
    var city = "north york"
    var postalcode = "m1h1y1"
}

var mylambton = inst()
print("mylambton street:",mylambton.street)
print("mylambton city:",mylambton.city)
print("mylambton postalcode:", mylambton.postalcode)

var mycestar = mylambton
print("mycestar street:",mycestar.street)
print("mycestar city:",mycestar.city)
print("mycestar postalcode:",mycestar.postalcode)

mycestar.street = "271 yorkland blvd"
mycestar.postalcode = "m3h3y3"
print("mycestar street:" ,mycestar.street)
print("mycestar postalcode:",mycestar.postalcode)


print("mylambton street:",mylambton.street)
print("mylambton postalcode:",mylambton.postalcode)


print("mylambton city:",mylambton.city)
print("mycestar city:",mycestar.city)



/// identical to means:      "==="

if mylambton === mycestar
{
    print("lambton and cestar are same")
}
else
{
    print("lambton and cestar are not same")
}

var yourcestar = inst()
if yourcestar === mycestar
{
    print("yourcestar and mycestar are same")
}
else
{
    print("yourcestar and mycestar are not same")
}





