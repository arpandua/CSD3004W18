//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


print(str)

let strOne = """
this is nav kaur student id: c0728813
i'm so so talkative
that i eat everyone's brain in my breakfast lunch and dinner
ok, enough of me🤪
"""
print(strOne)

var mood = " "
let heart = "\u{1F496}"

mood = "happy"
if mood.isEmpty
{
    print("cheer up")
}
else
{
    print(heart)
}


mood += " cheerful joyful"
print(mood)



///////


var firstname = String()
firstname = "Arpan"
print(firstname)

 for i in firstname
{
    print(i)
    
}


let initial : Character = "M"
firstname.append(initial)
 print(firstname)


print("first name is \(firstname) which is \(firstname.count) characters long")

print("start Index:", firstname[firstname.startIndex])


    print("before end index: ", firstname[firstname.index(before: firstname.endIndex)])
print("after start index:" , firstname [firstname.index(after: firstname.startIndex)])



print("5th character:" , firstname[firstname.index(firstname.startIndex,offsetBy: 4)])



var lang = "swift"
print("language : ", lang)

lang.insert("!",at: lang.endIndex)
print(lang)



var word = String()
word = "arpan"

print(word)




print("name is \(word) which is \(word.count) characters long")



for i in word
{
    print(i)
}


// 1st Character

print("1st Character", word[word.startIndex])


// 2nd Character

print("2nd character:" , word[word.index(word.startIndex,offsetBy: 1)])

/// 3rd character

print("3rd character:" , word[firstname.index(word.startIndex,offsetBy: 2)])

//4th character

print("4th character:" , word[firstname.index(word.startIndex,offsetBy: 3)])

///5th character

print("5th character:" , word[firstname.index(word.startIndex,offsetBy: 4)])


print("4th character from reverse:" , word[word.index(word.endIndex,offsetBy: -1)])

print("3rd character from reverse:" , word[word.index(word.endIndex,offsetBy: -2)])


print("2nd character from reverse:" , word[word.index(word.endIndex,offsetBy: -3)])

print("1st character from reverse:" , word[word.index(word.endIndex,offsetBy: -4)])

print("1st character from reverse:" , word[word.index(word.endIndex,offsetBy: -5)])




for i in word
{
    print(i)
}

////



    
    
    
    

