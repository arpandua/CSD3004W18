//: Playground - noun: a place where people can play   👻

import UIKit

var str = "Hello, playground"

var a = [10,20,30,40,50]

print("a[0] : \(a[0])")

let j1 = [10,20]
print("j1 : ",j1)



//////     use methods to add values   😈  /////////

var b = [Int]();

print("size of array b: \(b.count)")

b.append(100)
print("b[0]: \(b[0])")

b.append(1000)
print("b : ",b)

b[0] = 1000

/*b[2] = 500
print("b: ,b))
print("b[0] : \(b[0])")

print("size of array b: \(b.count)")       🤷🏻‍♂️
*/


///assigning the default value   🙋🏻‍♂️



var num1 = [Int](repeating: 1 ,count: 3)
print("num1 array :\(num1)")

var num2 = [Int](repeating: 5,count: 3)
print("num2 array: \(num2)")

var nummerge = num1 + num2
print("numMerge array: \(nummerge)")


// declare to store any data type   👯‍♂️

var c = [Any]();
print("size of array c is: \(c)")

c.append(100)
c.append("arpan")
c.append(101.1)

print("c : \(c)")




var x = a[1...3]
for t in x
{
    print("x : \(t)")
}


///string array and for-each with(key, value)    🐼


var shoppinglist: [String] = ["eggs","milk"]

for (index, value) in shoppinglist.enumerated()
{
    print("item \(index): \(value)")
}

print("the shopping list contains \(shoppinglist.count) items")
if shoppinglist.isEmpty
{
    print("the shopping list is empty :")
}
else
{
    print("the shopping list is not empty: ")
}
shoppinglist.append("flour")

shoppinglist += ["chocolate spread", "cheese", "butter"]
print(" shopping lista array:\(shoppinglist)")


///insert into an array   🌝

shoppinglist.insert("maple syrup", at: 0)
let maplesyrup = shoppinglist.remove(at: 2)

print("shopping list array: \(shoppinglist)" )




////// declaring set in swift   🍕

var grades: Set<Character> = []
grades.insert("A")
grades.insert("B")
print("grades : \(grades)")

print("grades no. of elements",grades.count)

///var gradType:Set <Any> = []   🍉  🍇



var favgeneres: Set<String> = ["rock","pop","edm"]
print(" fav generes \(favgeneres)")

print(" i have \(favgeneres.count) fav music generes")

if favgeneres.isEmpty
{
    print("as far as music goes, I'm not picky")
}

else
{
print("i have music preferences")
}

favgeneres.insert("jazz")
print("fav generes: \(favgeneres)")

for genre in favgeneres.sorted()
{
    print("\(genre)")
    }
let oddDigits: Set = [1,3,5,7,9]
let evenDigits: Set = [2,4,6,8,0]

let singleDigitPrimeNum: Set = [2,3,5,7]

print(oddDigits.union(evenDigits).sorted())
print(oddDigits.intersection(evenDigits).sorted())
print(oddDigits.subtracting(singleDigitPrimeNum).sorted())
print(oddDigits.symmetricDifference(singleDigitPrimeNum).sorted())



let houseanimals: Set = ["🐼","🐨"]
let farmanimals: Set = ["🐼","🐨","🐝","🐥"]
let cityanimals: Set = ["🐙","🦋"]

print(houseanimals.isSubset(of: farmanimals))
print(farmanimals.isSuperset(of: houseanimals))
print(farmanimals.isDisjoint(with: cityanimals))

