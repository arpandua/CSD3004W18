//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



// dictionaries


var names  = [Int: String]()       //names of integers is an empty set

names[16] = "sixteen"          //now 1 value added

print("names: ",names)


names[8] = "eight"
print("names: \(names.count)" ,names)

names = [:]                    // once again an empty set of same above type

print("names:",names)

print("dic contains \(names.count) elements")

print("names:",names)

 if names.isEmpty
{
    print("dictionary is empty")
}
 else
{
    print(names)
}



var airports: [String: String] = ["YYZ": "Toronto Pearson airport", "IGI": "new delhi","LAX": "Los Angeles"]

print("AIRPORTS: \(airports.count)",airports)

airports["LHR"] = "London Heathrow Airport"     // new value added
airports["YYZ"] = "TORONTO"                 // name change for YYZ

print(airports)


let oldValue = airports.updateValue("New Delhi Aiport",forKey: "IGI")
print("old value for IGI was \(oldValue)")
//prints the old value for IGI


if let airports = airports["AMD"]
{
    print("name is : ",airports)
    
}
else
{
    print("no such airports in dictionary")
    }

print(airports)

airports["Mars"] = "Range Rover"

print(airports)

airports["Mars"] = nil

print(airports)


if let removedvalue = airports.removeValue(forKey: "Mars")
{
    print("removed values is",removedvalue)
}
else{
    print("dicitionary does not contain such value")
}


for (airportcode, airportname) in airports
{
    print("airport code: ",airportcode)
}


for airportname in airports.values{
    print("airport name: ",airportname)
}

for airportcode in airports.keys
{
    print("airport code",airportcode)
}

let airportcode = [String](airports.keys)
print("airportcode :" ,airportcode)  /// airport is [........]


let airportname = [String](airports.values)
print("airportnames : " ,airportname)


//<key,value> pairs

var d1 : Dictionary<String, String> = ["India": "Hindi","Canada": "english"]
print(d1)

print(d1.description)

print(d1["India"]!)

print(d1["Canada"]!)


d1["China"] = "mandarin"
for(k,v) in d1{
    print("\(k) : \(v)")
}



var d2 = ["India": "Hindi","Canada": "English"]
for(k,v) in d2
{
    print("\(k) : \(v)")
}
 //// dictionary with any value types

var d3 = [String: AnyObject]()
d3 ["first name"] = "ARPAN" as AnyObject
d3 ["Last name"] = "DUA" as AnyObject
d3 ["Age"] = Int(2) as AnyObject
d3 ["salary"] = nil
print("d3",d3)

/////getting as a key, value pair

for(k,v) in d3
{
    print("\(k) : \(v)")
}

// getting as  a single object

for obj in d3
{
    print("\(obj.key) : \(obj.value)")
}



/// declaring tuples

var x = (10,20,30,40)
print(x.0)
print(x.1)
print(x.2)
print(x.3)


let Http404error = (404,"not found")

print(Http404error)

let(statuscode, statusmessage) = Http404error
print("statuscode:",statuscode)
print("statsumessage: ",statusmessage)


let(codeonly, _) = Http404error
print("codeonly:",Http404error)

let errordescription = (Code: 404, Message: "not found")
print(errordescription.Code,errordescription.Message)





///////////// FUNCN   /////////////


///DESCLARING A FUNCN



func add()
    {
        print("i'm in user defined function")
}

add()

func add(n1:Int, n2:Int)
{
    var sum : Int
sum = n1 + n2
    print("sum  : ",sum)
}

add(n1:10, n2:20)

                        //add(20,10)
            //errors
                        //add(n2:30, n1:40)



///single parameter

func welcome(name:String)
{
    print("hello, \(name)")
}
welcome(name: "A Dua")





///////making parameter label optional using _


func sub(a:Int, _ b:Int)
{
    let c = a - b
    print("sub: \(c)")
}
sub(a: 30, 20)

///single return type


func mul(a:Int, b:Int)
{
    let c = a * b
print(c)
}



///multi return value


func swipe(number1 a: Int, b:Int) -> (Int,Int)
{
    
    /// funcn parameter are constants by default
    // var temp = a
    // a=b
    //b=temp
     return(b,a)
    
}
var (b,a) = swipe(number1 : 10, b: 20)

print("a: \(a), b: \(b)")

    var(_,c) = swipe(number1: 10,b : 20)
    print("c : \(c)")


/////inout concept

func swipe(aa: inout Double, bb: inout Double)
{
    let temp = aa
    aa = bb
    bb = temp
}
var x1 = 8.0 , y = 9.0
swipe(aa:&x1 , bb:&y)
print("x: \(x1), y: \(y)")

////// default parameter

func  simpleinterest(amount: Double, noOfyears: Double, _ rate:Double = 5.0) -> Double
{
    let si = amount * rate * noOfyears / 100
    return si
}

print("simple interest: \(simpleinterest(amount: 1000,noOfyears: 5))")
print("simple interest: \(simpleinterest(amount: 1000,noOfyears: 5, 10))")

// variadic parmaters
func display(n:Int...)

{
    for i in n{
        print(i)
        
    }
}
display(n: 1,2,3,4,5)
display(n: 10,20,30)

/// passing array as parameter
func display(numbervalues: Int,parameters: [Int]...)
{
    print("no. of values",numbervalues)

    for i in parameters{
        print("i: ",i)
    }
    
}
var arr = [1,2,3,4,5,]
display(numbervalues: 3, parameters:arr,arr,arr)

////sum of 2 array's

func display(arraylist:[Int]...) -> [Int]
{
    var array1 = arraylist[0]
    var array2 = arraylist[1]
    var result = [Int]()
    if array1.count == array2.count
    {
        for i in 0..<array1.count
        {
            result.append(array1[i] + array2[i])
        }
    }
    return result
}

var a1 = [1,2,3,4,5]
var a2 = [6,7,8,9,10]

var a3 = display(arraylist: a1,a2)

print("array1",a1)
print("array2",a2)
print("sum of 2 arrays:",a3)


/////////////  TASK 3  ////////////////


func factorial (_ a: Int) -> Int
{
    
    if a == 0
    {
        return 1
    }
    else
    {
        return a * factorial(a - 1)
    }
}
let num = 5
let result = factorial(num)
print(result)



 
