//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



///////////  TASK 1  /////////

/* Difference between tuple and dictionary

1) Tuple returns multiple values from a method
2) Tuple don't need key-value pair but dictionary needs
3) Tuple contains predefined variables whereas dictionary does not hav pre defined values.
4) Tuple contains different data types whereas dictionary contains one data type value at a time.
 

 
 
 /////////////  TASK 3  ////////////////
 */
 
 
 func factorial (_ a: Int) -> Int
 {
 
 if a == 0
 {
 return 1
 }
 else
 {
 return a * factorial(a - 1)
 }
 }
 var num = 5
 var result = factorial(num)
 print(result)
 
