//
//  permanentclass.swift
//  arpan1
//
//  Created by Arpan Dua on 02/02/18.
//  Copyright © 2018 Arpan Dua. All rights reserved.
//

import Foundation



class permanentemp : emp
{
    var vacweeks : Int?


override init()
{
    super.init()
    self.vacweeks = 0
}

    init(eid: Int,enm: String,epay: Double,weeks: Int?)
{
    super.init(ID: eid,en: enm,pay: epay)
    self.vacweeks = weeks
}


    override func display()
    {
        super.display()
        print("vacation weeks:",vacweeks!)
    }
}



var obj2 = permanentemp()

