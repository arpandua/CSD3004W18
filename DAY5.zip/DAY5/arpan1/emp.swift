//
//  emp.swift
//  arpan1
//
//  Created by Arpan Dua on 02/02/18.
//  Copyright © 2018 Arpan Dua. All rights reserved.
//

import Foundation

class emp
{
    var empid: Int?
    var empname: String?
    var basicpay: Double?

    init()
    {
        self.empid = 0
        self.empname = " "
        self.basicpay = 0
    }
    
    init(ID: Int, nm: String, pay: Double) {
        self.empid = ID
        self.empname = nm
        self.basicpay = pay
}


    
    func display()
    {
        print("emp id:",self.empid!)
        print("emp name:",self.empname!)
        print("emp basic salary:",self.basicpay!)
}

    
}


var emp1 = emp()
emp1.empid = 101
emp1.empname = "arpan"
emp1.basicpay = 9900.00
