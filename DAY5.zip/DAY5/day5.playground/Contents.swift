//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


class emp
{
    var empid: Int?
    var empname: String?
    var basicpay: Double?
    
    
    ///initializers
    
    init()
            {
                self.empid = 0
                self.empname = " "
                self.basicpay = 0
            }
    
    init(ID: Int, nm: String, pay: Double) {
        self.empid = ID
        self.empname = nm
        self.basicpay = pay
    }
    
    
    
    
func display()
{
    print("emp id:",self.empid!)
    print("emp name:",self.empname!)
    print("emp basic salary:",self.basicpay!)
}

    // deinitializers
    deinit {
        print("emp obj deinitializer")
    }

}


var emp1 = emp()
emp1.empid = 101
emp1.empname = "arpan"
emp1.basicpay = 5000.00
emp1.display()

            //inheriting

class permanentemp : emp
{
    var vacweeks : Int?

// default inititalizer
    
    override init()
    {
        super.init()
        self.vacweeks = 0
    }
    
    /// parameterized initializers of subclass
    
    
    init(eid: Int,enm :String,epay: Double,weeks: Int?)
        {
            super.init(ID: eid,nm: enm,pay: epay)
            self.vacweeks = weeks
        }
        
    
    override func display()
    {
        super.display()
        print("vacation weeks:", vacweeks!)
    
    }

}

var obj2 = permanentemp()
obj2.empid = 102
obj2.empname = "Tuan"
obj2.basicpay = 5000.00
obj2.vacweeks = 8
obj2.display()

var emp3 = emp()
emp3.display()

var emp4 = emp(ID: 104,nm: "navneet",pay: 4500.00)
emp4.display()


 var obj5 = permanentemp()
obj5.display()

var obj6 = permanentemp(eid: 106, enm: "keshu", epay: 1200.00, weeks: 1)
obj6.display()




class Payroll : permanentemp {
    
    var finalpay : Double?
    
    // explicit call for
    //var finalpay: Double{
    //  get{
    // }
    
    override init() {
        super.init()
        self.finalpay = 0.0
    }
    
    
    
    override init (eid : Int, enm: String,epay: Double, weeks: Int?){
        super.init(eid: eid, enm: enm, epay: epay, weeks: weeks)
        self.finalpay = 0
    }
    
    
    override func display() {
        
        print("***********************************************")
        print("****************class activity*****************\n")
        super.display()
        
        if (super.vacweeks! > 5){
            finalpay = super.basicpay! - 100
            print(finalpay!) }
        else
        {
            print (finalpay!)
            
        }
    }
}


var obj7 = Payroll (eid: 110, enm: "jaydeep", epay: 1000, weeks: 6 )
obj7.display()



var janpayroll = [Payroll]()
let noOfemp = 2

for i in 0..<2  {
    janpayroll.append(Payroll(eid: 107 , enm: "AD",epay: 5555.77,weeks: 7))
janpayroll[i].display()
}

