var myname = "arpan";

print("my name is \(myname) which is \(myname.count) character long")

for i in myname
{
    print(i)
}


for i in stride(from: 0, to: myname.count, by: 1)
{
    let k = myname[myname.index(myname.endIndex, offsetBy: (-i - 1))]
print(k)
}
