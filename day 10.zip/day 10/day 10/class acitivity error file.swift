//
//  class acitivity error file.swift
//  day 10
//
//  Created by Arpan Dua on 09/02/18.
//  Copyright © 2018 Arpan Dua. All rights reserved.
//

import Foundation


enum xyz: Error
{
    case speeding()
    case redlightbrake()
    case seatbelt()
    case invalidlicence()
}

struct ticketing
{
    var speedlimit: Int
    var licencedyears: Float
    var seatbelt: Bool
    var licence: Bool

}


