//
//  main.swift
//  day 10
//
//  Created by Arpan Dua on 09/02/18.
//  Copyright © 2018 Arpan Dua. All rights reserved.
//

import Foundation

//throw limitincreaseerror.ineligible


var abc = requestlimitincrease()
//try abc.increaselimit(acccountno: "s1100")



var processrequest = requestlimitincrease()

/*do
{
        try processrequest.increaselimit(acccountno: "s1100")
    
}
catch limitincreaseerror.insufficientbalance
{
    print("you don't have sufficient balance")
    
}

catch limitincreaseerror.ineligible
{
    print("you don't have account with us")
}
catch limitincreaseerror.nosavingaccount
{
    print("limit inc is only available to saving accounts")
}
catch
{
print("unexpected error")
}

*/



/*do
{
    try processrequest.increaselimit(acccountno: "s1300")
}
catch is limitincreaseerror
{
    print("something wrong with your account")
}

 
 
 
 //////////////////            ///////////////
 
 
 

do
{

try processrequest.increaselimit(acccountno: <#T##String#>)

}

catch is limitincreaseerror
{
    print("error i")
}

*/



//////////////







var obj = trafficrequest()

do
{
    try obj.ticketingeligibility(CodeObjec: "driver 4")
}
catch xyz.speeding
{
    print("speeding: ")
}
catch xyz.redlightbrake
{
    print("red light:")
}
catch xyz.seatbelt
{
    print("seat belt:")
}
catch xyz.invalidlicence
{
    print("invalid: ")
}

