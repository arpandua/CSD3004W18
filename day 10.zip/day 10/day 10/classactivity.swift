import Foundation

class trafficrequest
{
    var trafficrequest =
        [
            "driver 1": ticketing(speedlimit: 150, licencedyears: 2, seatbelt: true, licence: true),
            
            "driver 2": ticketing(speedlimit: 180, licencedyears: 2,seatbelt: true, licence: true),
            
            "driver 3": ticketing(speedlimit: 20,licencedyears: 1, seatbelt: false, licence: true),
            
            "driver 4": ticketing(speedlimit: 40, licencedyears: 3, seatbelt: true, licence: false)
    ]
    
    
    
    func ticketingeligibility(driver: String)
        throws
    {
        guard var verifyObject = trafficrequest[driver]
            else
        {
            throw xyz.invalidlicence()
        }
        
        guard verifyObject.speedlimit < 50
            else
        {
            throw xyz.speeding()
        }
        
        guard verifyObject.licencedyears < 2
            else
        {
            throw xyz.invalidlicence()
        }
        guard verifyObject.seatbelt == true
            else
        {
            throw xyz.seatbelt()
        }
        
        
        
        
    }
}
