//
//  requstlimitincrease.swift
//  day 10
//
//  Created by Arpan Dua on 09/02/18.
//  Copyright © 2018 Arpan Dua. All rights reserved.
//

import Foundation


class requestlimitincrease
{
    

var requestreceived =
[
    "s1100" : requestsfromaccount(type: "saving",balance: 5000.09,reqstatus: "in progress"),
    "s1200" : requestsfromaccount(type: "saving" ,balance: 3080.09,reqstatus: "in progress"),
    "s1300" : requestsfromaccount(type: "chequing", balance: 3020.23,reqstatus:  "in progress"),
    "s1400" : requestsfromaccount(type: "saving", balance: 5400 , reqstatus: "approved")
]



func testeligibility(accountno acno: String)
{
    
}

func increaselimit(acccountno acno: String)
throws{
   
    guard let reqacc = requestreceived[acno]
        else {
            throw limitincreaseerror.ineligible
    }
    
    guard reqacc.reqstatus == ""
    else
    {
        throw limitincreaseerror.nosavingaccount
        
    }
        guard reqacc.balance >= 5000
    else
        {
            throw
            limitincreaseerror.insufficientbalance(balanceneeded: 4000-reqacc.balance)
            }
    


    var approvedrequest = reqacc
    approvedrequest.reqstatus = "approved"
    print("your request is approved")
    
    
}
}

