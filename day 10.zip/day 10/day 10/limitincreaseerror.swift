//
//  limitincreaseerror.swift
//  day 10
//
//  Created by Arpan Dua on 09/02/18.
//  Copyright © 2018 Arpan Dua. All rights reserved.
//

import Foundation


enum limitincreaseerror: Error
{
    case insufficientbalance(balanceneeded: Double)
    case nosavingaccount
    case ineligible
}

struct requestsfromaccount
{
    var type: String
    var balance: Double
    var reqstatus: String
}


