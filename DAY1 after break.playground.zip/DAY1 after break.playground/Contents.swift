//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let pi = 3.14
print("pi = ",pi)

let myNum:Int?// optional

myNum = 10
if myNum != nil
{
    print("myNum : ",myNum)
}
else {
    print("myNum is nil")
}

if myNum != nil
{
    print("myNum : ",myNum!)
}
else {
    print("myNum is nil")
}
let possibleNumber = "hello"
let convertedNumber = Int(possibleNumber)
if convertedNumber != nil
{
    print("Converted Number" , convertedNumber!)
}
else
{
    print("Converted Number is nil")
}



//
let possibleNumber5 = "213"
let convertedNumber5 = Int(possibleNumber5)
if convertedNumber5 != nil
{
    print("Converted Number5" , convertedNumber5!)
}
else
{
    print("Converted Number5 is nil")
}


//

for i in 1..<8
{
print("i 😎 =",i)
}

let languages: [String]
languages = ["english","spanish","french"]
for i in languages {
    print("language : " , i)
}


///

var answer: Int = 1
for _ in 1...5{
    answer *= 5;
}
print("answer = ",answer)

///



///
var Interval:Int = 5
for i in stride(from: 0, to: 80, by: Interval)
{
    print(i," ",terminator: " ")
}


///////

var j = 0
while(j < 5)
{
print("value of j is",j)
j=j+1
    }

j = 5
repeat{
    print("repeat : ",j)
    j = j + 2
} while (j<10)




///////

var num1 = 12

switch num1 {

case 100 :
    print("value of num1 is 100")
    case 10,15 :
print("value of num1 is either 10 or 15")
    
    case 5 :
    print("value of num1 is 5")

    default :
    print("default case ")
}








////////////



















